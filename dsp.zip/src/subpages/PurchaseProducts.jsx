import React from "react";
import Footer from "../pages/Footer";
import Icon from "../assets/icon.png";

const PurchaseProducts = () => {
  return (
    <div class="flow-wall">
      <div class="scroll-wall">
        <div class="headline">
          <i class="fa fa-rocket"></i>
          <div class="textline">
            <h2>Our Valued Products</h2>
            <p>There are 1 products for you.</p>
          </div>
        </div>
        <div className="search-bar">
          <div className="input">
            <div className="icon">
              <i className="fa fa-search"></i>
            </div>
            <input
              type="search"
              name="search"
              id="search"
              placeholder="Search anything here..."
            />
            <div className="srch-btn">
              <i className="fa fa-search"></i>
              <p>Search</p>
            </div>
          </div>
        </div>

        <div className="grid-bar">
          <div className="grid-card">
            <div className="image">
              <img src={Icon} alt="" />
            </div>
            <div className="text-panel">
              <h4>Sonata&reg;</h4>
              <p>Time management software</p>
            </div>
          </div>
        </div>
        <div class="body-txt">
          <p>
            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Provident
            temporibus dignissimos ullam exercitationem, itaque eum quis
            eligendi incidunt quas deserunt minima ut et quos. Atque explicabo
            deleniti repudiandae maxime fugiat, quisquam exercitationem
            perspiciatis optio quis dolores aut, illo nostrum quae esse autem?
            Deleniti magnam impedit consequuntur distinctio expedita voluptate
            reprehenderit.
          </p>
        </div>
        <div class="tags-bar">
          <ul>
            <li>
              <i class="fa fa-tag"></i>News
            </li>
            <li>
              <i class="fa fa-tag"></i>dspace
            </li>
            <li>
              <i class="fa fa-tag"></i>about
            </li>
            <li>
              <i class="fa fa-tag"></i>blog
            </li>
            <li>
              <i class="fa fa-tag"></i>explore
            </li>
          </ul>
        </div>
      </div>
      <Footer />
    </div>
  );
};
export default PurchaseProducts;
