import "./App.css";
import Home from "./pages/Home";
import Products from "./pages/Products";
import Events from "./pages/Events";
import Media from "./pages/Media";
import Profile from "./pages/Profile";
import { Link, Route, Routes } from "react-router-dom";
import React, { useEffect, useState } from "react";
import ViewProducts from "./subpages/ViewProducts";
import PurchaseProducts from "./subpages/PurchaseProducts";

function App() {
  const [bigging, setBigging] = useState(true);
  useEffect(() => {
    if (localStorage.getItem("dsp-login-status")) {
      if (localStorage.getItem("login")) {
        setBigging(false);
      } else {
        localStorage.setItem("login", "signin");
      }
    } else {
      localStorage.setItem("dsp-login-status", false);
    }
  }, [bigging]);
  return (
    <>
      <nav>
        <ul>
          <li>
            <Link to={"/home"}>
              <i className="fa fa-home fa-gradient"></i>
            </Link>
          </li>
          <li>
            <Link to={"/products"}>
              <i className="fa fa-rocket fa-gradient"></i>
            </Link>
          </li>
          <li>
            <Link to={"/media"}>
              <i className="fa fa-images fa-gradient"></i>
            </Link>
          </li>

          <li>
            <Link to={"/events"}>
              <i className="fa fa-trophy fa-gradient"></i>
            </Link>
          </li>
          <li>
            <Link to={"/profile"}>
              {localStorage.getItem("dsp-login-status") !== true ? (
                <i className="fa fa-sign-in fa-gradient"></i>
              ) : (
                <i className="fa fa-skull fa-gradient"></i>
              )}
            </Link>
          </li>
        </ul>
      </nav>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/home" element={<Home />} />
        <Route path="/products" element={<Products />} />
        <Route path="/media" element={<Media />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/events" element={<Events />} />
        <Route path="/view_products" element={<ViewProducts />} />
        <Route path="/purchase_products" element={<PurchaseProducts />} />
      </Routes>
    </>
  );
}

export default App;
