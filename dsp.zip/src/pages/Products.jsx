import Footer from "./Footer";

function Products() {
  return (
    <div className="wall">
      <div class="post">
        <div class="logo">
          <img src="DLM.png" alt="Logo" />
        </div>
        <h4>Products and status</h4>
        <p>
          At Dspace.lk, we pride ourselves on offering a diverse range of
          cutting-edge multimedia products designed to meet the unique needs of
          our clients. From state-of-the-art software solutions to visually
          stunning digital content, our products are crafted with precision and
          creativity. Dive into our product offerings and discover how we can
          help you achieve your digital goals with excellence and innovation.
        </p>
        <div class="btn-bar">
          <div
            class="btn-bx"
            onClick={() => (window.location.href = "/view_products")}
          >
            <i class="fa fa-search"></i> products
          </div>
          <div
            class="btn-bx"
            onClick={() => (window.location.href = "/purchase_products")}
          >
            <i class="fa fa-shopping-cart"></i> purchase
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}

export default Products;
