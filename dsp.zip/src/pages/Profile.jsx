import { useState } from "react";
import Sign from "./Sign";
import User from "./User";

function Profile() {
  const login = useState(
    localStorage.getItem("dsp-login-status").length > 0
      ? localStorage.getItem("dsp-login-status")
      : null
  );

  return login !== true ? <Sign /> : <User />;
}
export default Profile;
