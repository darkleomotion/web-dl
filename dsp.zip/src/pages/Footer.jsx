import React from "react";

function Footer() {
  return (
    <footer>
      <ul>
        <li>
          <a href="/security">
            <i className="fa fa-shield"></i>
          </a>
        </li>
        <li>
          <label for="theme">
            <i className="fa fa-moon moon"></i>
          </label>
          <label for="theme">
            <i className="fa fa-sun sun"></i>
          </label>
        </li>
        <li>
          <a href="/cookie_policy">
            <i className="fa fa-cookie"></i>
          </a>
        </li>
        <li className="sml">
          <a href="/copyright">
            <i className="fa fa-copyright"></i>
          </a>
        </li>
      </ul>
      <p className="big">&copy;2024 Dark Leo</p>
      <ul>
        <li>
          <a href="callto:+768463836">
            <i className="fa fa-phone"></i>
          </a>
        </li>
        <li>
          <a href="mailto:support@dspace.lk">
            <i className="fa fa-envelope"></i>
          </a>
        </li>
        <li>
          <a href="https://maps.google.com">
            <i className="fa fa-location-arrow"></i>
          </a>
        </li>
        <li>
          <a href="https://www.github.com">
            <i className="fa fa-github"></i>
          </a>
        </li>
      </ul>
    </footer>
  );
}
export default Footer;
