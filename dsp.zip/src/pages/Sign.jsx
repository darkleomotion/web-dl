import React, { useEffect, useState } from "react";
import Footer from "./Footer";

function Sign() {
  const [login, setLogin] = useState(localStorage.getItem("login"));
  const [bigging, setBigging] = useState(true);
  useEffect(() => {
    setBigging(false);
  }, [bigging]);

  return (
    <div className="wall">
      {login === "signin" ? (
        <div class="post">
          <div class="logo">
            <img src="DLM.png" alt="Logo" />
          </div>
          <h4>sign in</h4>
          <p>Please use your cridentials to sign in.</p>
          <form action="" method="post">
            <div class="flex-bar">
              <div class="input">
                <i class="fa fa-at"></i>
                <input
                  type="text"
                  name="username"
                  id="username"
                  placeholder="Username"
                  required
                />
              </div>
            </div>
            <div class="flex-bar">
              <div class="input">
                <i class="fa fa-lock"></i>
                <input
                  type="password"
                  name="password"
                  id="password"
                  placeholder="Password"
                  required
                />
              </div>
            </div>
            <div class="flex-bar">
              <div class="remember">
                <input type="checkbox" name="remember" id="remember" />
                <label for="remember">
                  <p>Remember me</p>
                </label>
              </div>
              <div class="forgot">
                <a href="/forgot_password">Forgot Password?</a>
              </div>
            </div>

            <div class="btn-bar">
              <div class="btn-bx">
                <i class="fa fa-sign-in"></i> sign in
              </div>
              <div
                class="btn-bx cancel"
                onClick={() => {
                  setLogin("signup");
                  localStorage.setItem("login", "signup");
                }}
              >
                <i class="fa fa-link"></i> Sign up
              </div>
            </div>
          </form>
        </div>
      ) : (
        <div class="post">
          <div class="logo">
            <img src="DLM.png" alt="Logo" />
          </div>
          <h4>sign up</h4>
          <p>Please use valid details to register.</p>
          <form action="" method="post">
            <div class="flex-bar">
              <div class="input">
                <i class="fa fa-user"></i>
                <input
                  type="text"
                  name="username"
                  id="username"
                  placeholder="Username"
                  required
                />
              </div>
            </div>
            <div class="flex-bar">
              <div class="input">
                <i class="fa fa-at"></i>
                <input
                  type="email"
                  name="email"
                  id="email"
                  placeholder="Email Address"
                  required
                />
              </div>
            </div>
            <div class="flex-bar">
              <div class="input">
                <i class="fa fa-lock"></i>
                <input
                  type="password"
                  name="password"
                  id="password"
                  placeholder="Password"
                  required
                />
              </div>
            </div>
            <div class="flex-bar">
              <div class="input">
                <i class="fa fa-lock"></i>
                <input
                  type="password"
                  name="password"
                  id="password"
                  placeholder="Confirm Password"
                  required
                />
              </div>
            </div>
            <div class="flex-bar">
              <div class="remember">
                <input type="checkbox" name="remember" id="remember" />
                <label for="remember">
                  <p>I accept to terms & conditions.</p>
                </label>
              </div>
            </div>

            <div class="btn-bar">
              <div class="btn-bx">
                <i class="fa fa-link"></i> sign up
              </div>
              <div
                class="btn-bx cancel"
                onClick={() => {
                  setLogin("signin");
                  localStorage.setItem("login", "signin");
                }}
              >
                <i class="fa fa-sign-in"></i> Sign in
              </div>
            </div>
          </form>
        </div>
      )}
      <Footer />
    </div>
  );
}
export default Sign;
