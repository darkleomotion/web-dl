import { useEffect, useState } from "react";
import { v4 as uuidV4 } from "uuid";
import Footer from "./Footer";

function User() {
  const [user, setUser] = useState(
    localStorage.getItem("dsp-user")
      ? localStorage.getItem("dsp-user")
      : localStorage.setItem("dsp-user", "User" + uuidV4().substring(0, 3))
  );

  return (
    <div className="wall">
      <div className="post">
        <div class="user">
          <div className="img">
            <img src="DLM.png" alt="Logo" />
          </div>
        </div>
        <h4>Welcome back </h4>
        <p>{user}</p>
      </div>
      <Footer />
    </div>
  );
}
export default User;
