import React from "react";
import "../styles/body.css";
import Footer from "./Footer";

function Home() {
  return (
    <div className="wall">
      <div class="post">
        <div class="logo">
          <img src="DLM.png" alt="Logo" />
        </div>
        <h4>Welcome to dspace</h4>
        <p>
          At Dspace.lk, we specialize in developing cutting-edge multimedia
          services to bring your digital dreams to life. From stunning web
          designs to robust software solutions, our team of experts is dedicated
          to delivering innovative, high-quality products tailored to meet your
          unique needs. Join us on this journey to digital excellence.
        </p>
        <div class="btn-bar">
          <div
            class="btn-bx"
            onClick={() => (window.location.href = "/explore")}
          >
            <i class="fa fa-rocket"></i> Explore
          </div>
          <div
            class="btn-bx"
            onClick={() => (window.location.href = "/get_start")}
          >
            <i class="fa fa-chevron-right"></i> Get Started
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
export default Home;
